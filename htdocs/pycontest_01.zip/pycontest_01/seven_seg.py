def seven_seg(x):
	return " _  _ \n _| _|\n|_  _|\n"

